package net.hb.crud;

import java.util.List;

public interface BoardDAOImp {
	public void boardInsert(BoardDTO dto);
	public List  boardSelect();
    public BoardDTO  boardDetail(int data);
    public int   boardCount();
    public void  boardDelete(int data);
	public void  boardEdit(BoardDTO dto);
}//interface END
