package net.hb.crud;

import java.util.List;

public interface BoardServiceImp {
	public void  board_ServiceInsert(BoardDTO dto );
	public List  board_ServiceSelect( );
    public BoardDTO  board_ServiceDetail( int data);
    public int   board_ServiceCount();
    public void  board_ServiceDelete(int data);
	public void  board_ServiceEdit();
}//interface END
