package net.hb.crud;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate; //dao-context.xml���� �Ǹ������� bean����ȭ
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class BoardDAO implements BoardDAOImp{

	@Autowired
	SqlSessionTemplate temp;
	
	public void boardInsert(BoardDTO dto) {
		System.out.println("boardInsert");
		System.out.println(dto.getName());
		System.out.println(dto.getTitle());
		System.out.println(dto.getContent());
		System.out.println(dto.getGender());
		System.out.println(dto.getHobby());
		System.out.println(dto.getImg_file_name());
		
	   temp.insert("board.add", dto);
	}//end
	
	public List<BoardDTO>  boardSelect( ) { 
		List<BoardDTO> list = temp.selectList("board.selectAll") ;
		return list;
	}//end
	
	public int  boardCount() { 
		int result = temp.selectOne("board.countAll");
	  return result;
	}//end
	   
    public BoardDTO boardDetail( int data ) { 
      BoardDTO dto = temp.selectOne("board.selectDetail",data);	
      return dto;	
    }//end
    
    public void  boardDelete(int data) { 
    	temp.delete("board.deleteOne", data);
    }//end
    
	public void  boardEdit(BoardDTO dto) {
		temp.update("board.update", dto);
		System.out.println(dto.getName());
		System.out.println(dto.getTitle());
		System.out.println(dto.getContent());
		System.out.println(dto.getGender());
		System.out.println(dto.getImg_file_name());
		System.out.println(dto.getHobby_idx());
		
	}//end
	
	public List<String> boardSearch(BoardDTO dto){
		
		
		return null;
	}
	
}//BoardDAO class END






