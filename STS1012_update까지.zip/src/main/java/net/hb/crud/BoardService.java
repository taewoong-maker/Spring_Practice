package net.hb.crud;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Component
@Service
public class BoardService  implements BoardServiceImp{
	
	@Autowired
	BoardDAOImp dao;
	
	public void  board_ServiceInsert(BoardDTO dto){
		dao.boardInsert(dto);
	}//end
	
	public List  board_ServiceSelect( ){
		List LT = dao.boardSelect() ;
		return LT;
	}//end
	
    public BoardDTO board_ServiceDetail( int data){
    	BoardDTO dto = dao.boardDetail(data);
    	return dto;
    }//end
    
    public int   board_ServiceCount(){
    	int Hdata = dao.boardCount(); 
    	return Hdata;
    }//end
    
    public void  board_ServiceDelete(int data){
    	
    }//end
    
	public void  board_ServiceEdit(){
		
	}//end
	
}//class END
