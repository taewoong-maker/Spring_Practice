package net.hb.crud;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class BoardController {

	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);

	@Autowired
	ServletContext application;

	@Autowired
	BoardDAO dao;
	
	@Autowired
	BoardServiceImp bs; //dao ��� �����������̽� ����Ÿ�� ����. ������� ���� �ִ� �κ�

	@RequestMapping(value = "/boardWrite.do", method = RequestMethod.GET)
	public String board_write() {
		return "boardWrite"; // WEB-INF/views/boardWrite.jsp
	} // end

	@RequestMapping(value = "/boardInsert.do", method = RequestMethod.POST )
	public String board_insert(BoardDTO dto) {

		String path = application.getRealPath("/resources/upload");
		String img = dto.getUpload_f().getOriginalFilename();
//		System.out.println("path ��� : " +path);
//		System.out.println("img �׸� : " + img);

		// file ���·� �޾ƿ��� ���� �ڵ�
		File file = new File(path, img);
		try {
			dto.getUpload_f().transferTo(file);
		} catch (Exception e) {
			System.out.println("boardInsert.do ���Ͽø��� ����:" + e);
		}

		dto.setImg_file_name(img);
		dao.boardInsert(dto);
		return "redirect:/boardList.do"; // WEB-INF/views/boardWrite.jsp
	} // end

	@RequestMapping(value = "/boardList.do")
	public ModelAndView board_list(Model model) {
//		List<BoardDTO> list = dao.boardSelect();	
//		model.addAttribute("LG", list);
//		model.addAttribute("Gtotal", dao.boardCount());
		int Gtotal = bs.board_ServiceCount(); //���� ����
		List<BoardDTO> list =  bs.board_ServiceSelect();
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("Gtotal",Gtotal);
		mav.addObject("LG", list);
		mav.setViewName("boardList");
		
		return mav; // WEB-INF/views/boardWrite.jsp
	} // end
	
	@RequestMapping(value = "/boardDetail.do", method = RequestMethod.GET)
	public String board_detail(@RequestParam("idx") int data,Model model) {
		
		BoardDTO dto =  dao.boardDetail(data);		
		model.addAttribute("dto", dto);
		
		return "boardDetail"; // WEB-INF/views/boardWrite.jsp
	} // end
	
	@RequestMapping(value = "/boardDownload.do")
	public void board_download(@RequestParam("idx") String data,Model model,
												HttpServletResponse response) {
		String path = application.getRealPath("/resources/upload");
		String img = data;
		
		File file = new File(path, img);
		response.setHeader("Content-Disposition", "attachment; filename="+img);
		try {
			InputStream is=new FileInputStream(file); 
			OutputStream os=response.getOutputStream(); 
			
			byte[ ] bit=new byte[(int)file.length()];
			is.read(bit, 0, bit.length);
			os.write(bit); 
			is.close(); os.close();
		} catch (Exception e) {
			System.out.println("�ٿ�ε����:"+e);
		}
		
//		return "redirect:/boardList.do"; // WEB-INF/views/boardWrite.jsp
	} // end
	
	@RequestMapping(value = "/boardDelete.do")
	public String board_delete(@RequestParam("idx") int data) {
		System.out.println("aaaaaaaaaa");
		dao.boardDelete(data);
		
		return "redirect:/boardList.do"; // WEB-INF/views/boardWrite.jsp
	} // end
	
	

}// class END
